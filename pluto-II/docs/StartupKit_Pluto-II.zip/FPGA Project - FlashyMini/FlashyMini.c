// RS-232 FlashyMini example
// (c) fpga4fun.com KNJN LLC 2010
// Compiles with Microsoft Visual C++ 5.0/6.0 and Digital Mars C/C++ Compilers

// This works in conjunction with the "FlashyMini.v" file

#include <windows.h>
#include <stdio.h>
#include <conio.h>

HANDLE hCom;
char* COMport = "COM1:";  	// default is COM1, change it to use a different COM port

void ExitOnError(char*message)
{
	printf("%s error\n",message);
	printf("Press a key to exit");	getch();
	exit(1);
}

void OpenCom(char* COM_name)
{
	DCB dcb;
	COMMTIMEOUTS ct;

	hCom = CreateFile(COM_name, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hCom==INVALID_HANDLE_VALUE) ExitOnError(COM_name);  // can't open COM port
	if(!SetupComm(hCom, 4096, 4096)) ExitOnError("SetupComm");

	if(!GetCommState(hCom, &dcb)) ExitOnError("GetCommState");
	dcb.BaudRate = 115200;
	((DWORD*)(&dcb))[2] = 0x1001;  // set port properties for TXDI + no flow-control
	dcb.ByteSize = 8;
	dcb.Parity = NOPARITY;
	dcb.StopBits = 2;
	if(!SetCommState(hCom, &dcb)) ExitOnError("SetCommState");

	// set the timeouts to 0
	ct.ReadIntervalTimeout = MAXDWORD;
	ct.ReadTotalTimeoutMultiplier = 0;
	ct.ReadTotalTimeoutConstant = 0;
	ct.WriteTotalTimeoutMultiplier = 0;
	ct.WriteTotalTimeoutConstant = 0;
	if(!SetCommTimeouts(hCom, &ct)) ExitOnError("SetCommTimeouts");
}

void CloseCom()
{
	CloseHandle(hCom);
}

DWORD WriteCom(void* buf, int len)
{
	DWORD nSend;
	if(!WriteFile(hCom, buf, len, &nSend, NULL)) ExitOnError("WriteFile");

	return nSend;
} 

void WriteComChar(char b)
{
	WriteCom(&b, 1);
}

int ReadCom(void *buf, int len)
{
	DWORD nRec;
	if(!ReadFile(hCom, buf, len, &nRec, NULL)) ExitOnError("ReadCom");

	return (int)nRec;
}

char ReadComChar()
{
	DWORD nRec;
	char c;
	if(!ReadFile(hCom, &c, 1, &nRec, NULL)) ExitOnError("ReadComChar");

	return nRec ? c : 0;
}

void main()
{
	char s[1024];
	int i, len;

	OpenCom(COMport);
	printf("Running... ");

	// start acquisition by sending any character
	WriteComChar(0x41);
	Sleep(200);

	// receive ADC data
	len = ReadCom(s, sizeof(s));
	printf("got %d bytes... ", len);
	for(i=0; i<len; i++) printf("%d ", (unsigned char) s[i]);

	CloseCom();
	printf("Press a key to exit");	getch();
}
