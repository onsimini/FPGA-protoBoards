Pong game VGA demo
(c) 2004, 2005, 2006 fpga4fun.com KNJN LLC

See http://www.fpga4fun.com/PongGame.html for details.

This file requires a Pluto-II with a 25MHz on-board oscillator.

Before compiling this project, you may want to change the pin assignment.
Right now, it is as follow (from the "pong.qsf" file):
set_location_assignment PIN_50 -to vga_v_sync
set_location_assignment PIN_49 -to vga_h_sync
set_location_assignment PIN_48 -to vga_B
set_location_assignment PIN_47 -to vga_G
set_location_assignment PIN_41 -to vga_R
