// RS-232 FlashyDemo example
// (c) fpga4fun.com KNJN LLC - 2008, 2009

// This works in conjunction with the "FlashyDemo.rbf" FPGA bitfile
// Compiles with Microsoft Visual C++ 5.0/6.0 and Digital Mars C/C++ Compilers

///////////////////////////////////////////////////
#include <windows.h>
#include <assert.h>
#include <stdio.h>
#include <conio.h>

#define strCOM "COM4:"		// change that to use a different COM port

///////////////////////////////////////////////////
HANDLE hCom;

void ExitOnError(char*message)
{
	printf("%s error",message);
	exit(1);
}

void OpenCom(char* COM_name)
{
	DCB dcb;
	COMMTIMEOUTS ct;

	hCom = CreateFile(COM_name, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hCom==INVALID_HANDLE_VALUE) ExitOnError(COM_name);  // can't open COM port
	if(!SetupComm(hCom, 4096, 4096)) ExitOnError("SetupComm");

	if(!GetCommState(hCom, &dcb)) ExitOnError("GetCommState");
	dcb.BaudRate = 115200;
	((DWORD*)(&dcb))[2] = 0x1001;  // set port properties for TXDI + no flow-control
	dcb.ByteSize = 8;
	dcb.Parity = NOPARITY;
	dcb.StopBits = 2;
	if(!SetCommState(hCom, &dcb)) ExitOnError("SetCommState");

	// set the timeouts to 0
	ct.ReadIntervalTimeout = MAXDWORD;
	ct.ReadTotalTimeoutMultiplier = 0;
	ct.ReadTotalTimeoutConstant = 0;
	ct.WriteTotalTimeoutMultiplier = 0;
	ct.WriteTotalTimeoutConstant = 0;
	if(!SetCommTimeouts(hCom, &ct)) ExitOnError("SetCommTimeouts");
}

void CloseCom()
{
	CloseHandle(hCom);
}

DWORD WriteCom(void* buf, int len)
{
	DWORD nSend;
	if(!WriteFile(hCom, buf, len, &nSend, NULL)) ExitOnError("WriteFile");

	return nSend;
} 

int ReadCom(void *buf, int len)
{
	DWORD nRec;
	if(!ReadFile(hCom, buf, len, &nRec, NULL)) ExitOnError("ReadCom");

	return (int)nRec;
}

///////////////////////////////////////////////////
#define nFlashyChannels 1
#define AcqDataLen	1024
#define DataPacketVersion	2

void main()
{
	int i, ch, len;

	struct
	{
		WORD PktAdr;
		BYTE DAC[8];
		BYTE TriggerThreshold;
		BYTE PreTriggerPoint;
		BYTE FilterDataIn_HDiv;
		BYTE AcqAllowed_TriggerSlope;
	}
	TriggerRequest;

	struct DPH
	{
		WORD magic_number;	// 0x55AA
		BYTE version;		// 0x01
		BYTE nb_channels_and_ADCfreq;
	};

	struct
	{
		struct DPH hdr1;					// header
		BYTE samples[AcqDataLen*nFlashyChannels];	// data acquired from Flashy
		DWORD dummy[4];						// don't care data
		DWORD FC[3];						// frequency counters
		struct DPH hdr2;					// second header
	}
	DataPacket;

	// make sure the structures are packed
	assert(sizeof(TriggerRequest)==14);
	assert(sizeof(DataPacket)==AcqDataLen*nFlashyChannels+36);

	TriggerRequest.PktAdr = 0x0000;
	TriggerRequest.DAC[0] = 0xFF;	// max range and position
	TriggerRequest.DAC[1] = 0xFF;
	TriggerRequest.DAC[2] = 0xFF;
	TriggerRequest.DAC[3] = 0xFF;
	TriggerRequest.DAC[4] = 0xFF;
	TriggerRequest.DAC[5] = 0xFF;
	TriggerRequest.DAC[6] = 0xFF;
	TriggerRequest.DAC[7] = 0xFF;
	TriggerRequest.TriggerThreshold = 0;	// trigger now
	TriggerRequest.PreTriggerPoint = 128;	// half the data before the trigger, half after
	TriggerRequest.FilterDataIn_HDiv = 0;	// acquire at full speed
	TriggerRequest.AcqAllowed_TriggerSlope = 0x80;

	OpenCom(strCOM);
	WriteCom(&TriggerRequest, sizeof(TriggerRequest));	// send the trigger request
	Sleep(200);
	len = ReadCom(&DataPacket, sizeof(DataPacket));	// and get the data packet back

	if(len==sizeof(DataPacket) && DataPacket.hdr1.magic_number==0x55AA && DataPacket.hdr1.version==DataPacketVersion)
	{
		if((DataPacket.hdr1.nb_channels_and_ADCfreq & 0x0F)==nFlashyChannels)
		{
			if(DataPacket.hdr2.magic_number==0x55AA && DataPacket.hdr2.version==DataPacketVersion)
	{
		// display the data received
		for(ch=0; ch<nFlashyChannels; ch++)
		{
			printf("Channel %d: ", ch+1);
					for(i=0; i<AcqDataLen; i++) printf("%d ", DataPacket.samples[i+AcqDataLen*ch]);
			printf("\n");
		}
	}
		}
		else
			printf("Wrong number of Flashy channels (%d received, %d expected)\n", (DataPacket.hdr1.nb_channels_and_ADCfreq & 0x0F), nFlashyChannels);
	}
	else
		printf("Bad packet received\n");

	// now we could re-trigger to get more data if we wanted
	// but let's just exit
	printf("Press a key to exit"); getch();
	CloseCom();
}
