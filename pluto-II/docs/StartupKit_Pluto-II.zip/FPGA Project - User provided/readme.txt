These files are NOT SUPPORTED - USE AT YOUR OWN RISK!
_______________________________________________
fpgaconf-0.1.0.tar
http://www.mecanic.net/fpga/fpgaconf-0.1.0.tar.gz

Linux command-line configuration tool for Pluto
This utility sends an RBF file to the FPGA board.
_______________________________________________
flasher-0.1.tar.gz
http://www.yudit.org/uc/

Linux command-line configuration tool for Pluto
This utility sends an RBF file to the FPGA board.
_______________________________________________
Please note that depending on the board revision that you own, 
you may have to invert the 0xFE and 0xFF bytes sent by the 
software.
These utilities were created for Pluto but should also
work for Pluto-II/IIx.
