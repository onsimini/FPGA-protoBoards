##*****************************************************************************
## Copyright (c) 2006 Xilinx, Inc.
## This design is confidential and proprietary of Xilinx, Inc.
##All Rights Reserved
##*****************************************************************************
##   ____  ____
##  /   /\/   /
## /___/  \  /    Vendor: Xilinx
## \   \   \/     Version: Name: PCIe_Chipscope_Inserter Script 
##  \   \         Application: MIG
##  /   /         Filename: pcie_chipscope.pl
## /___/   /\     Date Last Modified: Date: 2007/05/09 07:23:02 
## \   \  /  \    Date Created: January 16 2006
##  \___\/\___\
##
##Design Name: XAPP #NUMBER  - Inserting Chipscope into Xilinx PCIe Solutions
##Purpose:
##   This script will insert Chipscope ILA and ICON cores into a top level
##   design netlist.  Default CDC files are created and the supported solutions
##   are.
##   1) PCIe 32 bit and 64 bit softcore
##   2) PCIe 32 bit PIPE core
##   3) PCIe Block Plus core
##
##   The script is also able to insert Chipscope ILA and ICON cores into any netlist
##   as long as a CDC project file correctly matches the netlist.  When ran, the script will prompt
##   the user for the CDC file and netlist.   There are three parts to this script that provide 
##   the necessary information to Chipscope Pro.

##Reference:
##Revision History:
##*****************************************************************************

## Get current working directory
use Cwd;
use File::Find;
use File::Copy;
$dir = getcwd();

rmdir with_chipscope;
mkdir with_chipscope;

##***************************************************************
## This section gets the device customer is targeting ***********
## Need this to identify which bscan component to use ***********
##***************************************************************
print "\n\n\nPlease enter the device you are targeting\n1)Virtex5\n2)Virtex4\n3)Virtex2Pro\n4)Spartan3\n5)Spartan3e\n:";

$device_used =<STDIN>; 

$device_fam = 0;
$cdc_folder = 0;

        if    ($device_used=~1)  {$device_fam =14; $cdc_folder = "Virtex5"; }     
        elsif ($device_used=~2)  {$device_fam =12; $cdc_folder = "Virtex4";}     
        elsif ($device_used=~3)  {$device_fam =3; $cdc_folder = "Virtex2P";}     
        elsif ($device_used=~4)  {$device_fam =6; $cdc_folder = "Spartan";}
        elsif ($device_used=~5)  {$device_fam =13; $cdc_folder = "Spartan";}
        elsif ($device_used=~6)  {$device_fam =15; $cdc_folder = "Spartan";}
        else            {print "Not a valid number"}  

##***************************************************************
## This section gets the design netlis to insert chipscope into *
##***************************************************************
print "\n\n\nEnter the number that correlates to the netlist you would like to install\nChipscope into.";

##		Examining directory to locate all NGC and NGO files
##-------------------------------------------------------------
$n = 0; #temp for loop
## Opens directory, lists all files with NGC or NGO extension in directory and 
## stores the names of the files into a 1-D array
opendir DIR, ".";  # . is the current directory $n = 0; #temp for while loop 
while ( $filename = readdir(DIR) ) 
	{ 
		if ($filename =~ /ngo$/ || $filename =~ /ngc$/) 
			{ 
				print "\n" , $n ,") ", $filename; 
				$ngcarray[$n] = $filename; 
				$n=$n+1; 
			} 
	} 
closedir DIR; 
print "\n:"; 
$temp =<STDIN>; 
$file_name = $ngcarray[$temp];



##     Check to verify entry has NGC or NGO extension
##-------------------------------------------------------
while (($file_name !~ /ngo$/) && ($file_name !~ /ngc$/))
{
		print "\n\n Entry is not a valid core netlist.  Please re-enter the netlist name:";
		@directory_file = <*>;
		$n = 0; # temp for loop
		opendir DIR, ".";  # . is the current directory $n = 0;
			while ( $filename = readdir(DIR) ) 
				{ 
					if ($filename =~ /ngo$/ || $filename =~ /ngc$/) 
						{ 
							print "\n" , $n ,") ", $filename; 
							$ngcarray[$n] = $filename; 
							$n=$n+1; 
						} 
				} 
closedir DIR; 
print "\n:"; 
$temp =<STDIN>; 
$file_name = $ngcarray[$temp];
}

## ===============================================================
## 		Identifying if input file is NGO.  If so, need to change NGO to NGC for Chipscope Inserter
## ===============================================================
if ($file_name =~ /ngo$/)
 { 
 	$file_name2 = $file_name;
 	print "\n\n";
 	chop($file_name2);
 	print "\n\n";
 	$file_name2 = $file_name2."c";
 	$CMDNGCBUILD = "ngcbuild $file_name $file_name2";
 	system($CMDNGCBUILD);
 	$file_name = $file_name2;
 	print "\n\n\n NGC file has been created out of NGO\n";
 }

##***************************************************************
## This section gets the design netlis to insert chipscope into *
##***************************************************************

##===========================================================================================
## 	This module does a recursive search in the C:\Xilinx directory for all Chipscope Installs
## 	It stores the install paths into arrays and the user is prompted for the build they would 
## 	like to use.  If no install is found in default location, user is prompted for Chipscope
## 	install path
##===========================================================================================

$p=0; # temp for loop	
$Chipscope_Base = "c:/Xilinx";

find(\&sub_module, $Chipscope_Base);

sub sub_module() 
{
				
    if ($_ =~ "inserter.exe")
    {
			if ($p =~ 0) 
				{
					print "\nPlease select the path correspoding to the Chipscope Version you would like to\nuse";
				}
    	print "\n",$p,") ", $File::Find::dir;
    	$chipscopearray[$p] = $File::Find::dir; 
    	$p=$p+1;   
		}
}

## Check to see if first element has valid path.  If no, implies Chipscope install not found
if ($chipscopearray[0] !~ /nt$/)
	{
		print "\n Chipscope install path not found in default location.  Please enter Chipscope \n Install Path (ex: C:\\Xilinx\\Chipscope_Pro_9_1i\\bin\\nt)\n:";
		$Chipscope_Dir = <STDIN>;
    $Chipscope_Dir =~ s/\s+$//; #remove end of line character
  }
## Fall through if >= 1 Chipscope install is found and ask user for the build they would ilke to use
else
	{ 
    print "\n:";
    $chipscope_temp =<STDIN>; 
    $Chipscope_Dir = $chipscopearray[$chipscope_temp];
  }

##===========================================================================================
##  This module does a recursive search in the directory and sub directories where the script
##  was extracted to.  It searches for all CDC files and prints them out the DOS console
## 	It stores the install paths into arrays and the user is prompted for the build they would 
## 	like to use.  If no install is found in default location, user is prompted for Chipscope
## 	install path
##===========================================================================================
$l=0; # temp for loop	
$k = 0;
$cdc_path = "$dir\\cdc\\$cdc_folder"; 

find(\&sub_module2, $cdc_path);
sub sub_module2() 
{

    if ($_ =~ /cdc$/)
    {
			if ($k =~ 0) 
				{
					print "\nPlease select the CDC file you would like to use";
					$k = $k+1;
				}
			print "\n",$l,") ", $_;
    	##print "\n",$l,") ", $File::Find::name;
    	$cdcarray[$l] = $File::Find::name; 
    	$l=$l+1;   
		}
}
## This section copies the selected chipscope CDC file and copies it to with_chipscope directory
print "\n:"; 
$cdctemp =<STDIN>; 
$cust_cdc = $cdcarray[$cdctemp];

## This verifies user entry is a .CDC.  If not creates array again and prompts user
	while ($cust_cdc !~ /cdc$/)
		{
			print "\n\n Entry is not a valid CDC file.  Please re-enter the CDC name (i.e. cust_ila.cdc):";
			##opendir DIR, ".";  # . is the current directory $n = 0; #temp for while loop 
			$l=0; # temp for loop	
			find(\&sub_mod, $dir);
			sub sub_mod() 
				{

    			if ($_ =~ /cdc$/)
    				{
							if ($k =~ 0) 
								{
									print "\nPlease select the CDC file you would like to use";
									$k=$k+1;
								}
    				print "\n",$l,") ", $File::Find::name;
    				$cdcarray[$l] = $File::Find::name; 
    				$l=$l+1;   
    				}
				}
		print "\n:"; 
		$cdctemp =<STDIN>; 
		$cust_cdc = $cdcarray[$cdctemp];
}


print "\n",$cust_cdc;
$cdccopy = "$dir\\with_chipscope\\chipscope_project.cdc"; 
copy($cust_cdc, $cdccopy);

open(CDCFILE,">>$dir\\with_chipscope\\chipscope_project.cdc");
print CDCFILE "Project.device.deviceFamily=$device_fam";
close(CDCFILE);
#=================================================================
# Call to Chipscope inserter to implement ICON and ILA cores into netlist given the selected CDC
#=================================================================

$CMD = "$Chipscope_Dir\\inserter -insert $dir\\with_chipscope\\chipscope_project.cdc -ngcbuild -dd $dir\\with_chipscope\\ $dir\\$file_name $dir\\with_chipscope\\$file_name";
system($CMD);

opendir w_chip, "$dir\\with_chipscope";  # . is the current directory  
while ($extname = readdir(w_chip) ) 
	{ 

		if ($extname =~ m/^icon_pro/ or $extname =~ m/^ila_pro/ or $extname =~ m/signalbrowser.ngo$/ or $extname =~ m/signalbrowser.ver$/ or $extname =~ m/.blc$/) 
			{ 
				unlink("$dir\\with_chipscope\\$extname");
			} 
	} 
closedir w_chip; 